package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import com.example.myapplication.TiposSanguineo;
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void actionButton(View v){
        //Entrada::
        //vinculo:
        EditText etT = findViewById(R.id.idN);
        TextView etR = findViewById(R.id.idN);
        //tratamento:
        String t = etT.getText().toString().toUpperCase();
        //Saída:
        try {
            Integer.parseInt(t);
            etR.setText("Apenas String");
        } catch (NumberFormatException e) {
            TiposSanguineo.TiposDeSangue TiposDeSangue = new TiposSanguineo().new TiposDeSangue();
            String resposta = TiposDeSangue.pesquisa(t);
            Toast.makeText(this,String.valueOf(resposta),Toast.LENGTH_LONG).show();
        }
    }
}