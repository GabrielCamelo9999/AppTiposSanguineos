package com.example.myapplication;

public class TiposSanguineo {
    public class TiposDeSangue{
        public String pesquisa(String n) {
            String tipo = "";
            switch (n) {
                case "A+":
                    // Pode receber de A+, A-, O+ e O-.
                    tipo = "Pode receber de:\n A+, A-,\n O+ e O-.";
                    break;
                case "A-":
                    // Pode receber de A- e O-.
                    tipo = "Pode receber de:\n A- e O-.";
                    break;
                case "B+":
                    // Pode receber de B+, B-, O+ e O-.
                    tipo = "Pode receber de:\n B+, B-,\n O+ e O-.";
                    break;
                case "B-":
                    // Pode receber de B- e O-.
                    tipo = "Pode receber de:\n B- \ne O-.";
                    break;
                case "AB+":
                    // Pode receber de A+, A-, B+, B-, O+ e O-.
                    tipo = "Pode receber de:\n A+, A-,\n B+, B-,\n O+ e O-.";
                    break;
                case "AB-":
                    // Pode receber de A-, B- e O-.
                    tipo = "Pode receber de:\n A-,\n B- \n e O-.";
                    break;
                case "O+":
                    // Pode receber de O+ e O-.
                    tipo = "Pode receber de:\n O+ e O-.";
                    break;
                case "O-":
                    // Pode receber de O-.
                    tipo = "Pode receber de:\n O-.";
                    break;
            }
            return tipo;
        }
    }
}

